# DualShock Overlay — v0.1.0

Starter Android Studio project for a dark, realistic-style DualShock 4 floating visualizer.

## Current prototype
- Detects connected gamepad/joystick input devices.
- Receives button and analog-stick events while the app is in the foreground.
- Requests Android's draw-over-other-apps permission.
- Starts a foreground service that displays a non-focusable floating controller panel.

## Important Android limitation
A normal third-party Android app cannot reliably monitor another app's gamepad key/axis events globally. When a game is in the foreground, Android routes controller input to that game; `InputDevice` listeners report device connection changes, not all global button presses. This prototype therefore does **not** claim that the overlay's buttons animate from game input yet. Achieving that behavior may require privileged/system-level access or a device-specific supported input-capture mechanism. Accessibility services are not a universal or reliable workaround for gamepad axes.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync; use JDK 17 and Android SDK 35.
3. Build > Build APK(s).
4. Install the debug APK on Android 10+.
5. Grant "Display over other apps" permission, then activate the overlay.

## Test controller
Pair the DualShock 4 in Android Bluetooth settings. Open the app and press buttons/move sticks to verify foreground input events. The device name appears in the status area.

## Next development milestone
Replace the text mockup with a vector/custom-drawn DualShock 4 shell, add draggable positioning and opacity/scale controls, then investigate a supported device-specific way to capture live gamepad state while a game is foregrounded.
