package com.kiuyulk.dualshockoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Static DS4-inspired artwork for the first overlay milestone. */
class ControllerView(context: Context) : View(context) {
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(35, 35, 43); style = Paint.Style.FILL }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(92, 87, 105); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(15, 15, 20); style = Paint.Style.FILL }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(225, 222, 234); textAlign = Paint.Align.CENTER; textSize = 25f; style = Paint.Style.FILL }
    private val muted = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(145, 139, 158); textAlign = Paint.Align.CENTER; textSize = 13f }
    private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(90, 150, 255); style = Paint.Style.FILL }
    private val pink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(244, 120, 170); style = Paint.Style.FILL }
    private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(105, 205, 145); style = Paint.Style.FILL }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(235, 105, 115); style = Paint.Style.FILL }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val save = canvas.save()
        val sx = width / 360f
        val sy = height / 205f
        canvas.scale(sx, sy)

        // Main controller shell and grips.
        val shell = Path().apply {
            moveTo(93f, 43f); cubicTo(72f, 42f, 58f, 61f, 48f, 94f)
            lineTo(25f, 160f); cubicTo(18f, 181f, 37f, 194f, 55f, 182f)
            lineTo(112f, 137f); cubicTo(145f, 126f, 215f, 126f, 248f, 137f)
            lineTo(305f, 182f); cubicTo(323f, 194f, 342f, 181f, 335f, 160f)
            lineTo(312f, 94f); cubicTo(302f, 61f, 288f, 42f, 267f, 43f)
            cubicTo(220f, 54f, 140f, 54f, 93f, 43f); close()
        }
        canvas.drawPath(shell, body); canvas.drawPath(shell, edge)
        // Touchpad and center light bar.
        canvas.drawRoundRect(RectF(137f, 53f, 223f, 99f), 9f, 9f, dark)
        canvas.drawRoundRect(RectF(157f, 103f, 203f, 106f), 2f, 2f, blue)
        // D-pad.
        canvas.drawRoundRect(RectF(78f, 77f, 94f, 125f), 3f, 3f, dark)
        canvas.drawRoundRect(RectF(62f, 93f, 110f, 109f), 3f, 3f, dark)
        // Face buttons.
        canvas.drawCircle(278f, 79f, 12f, green); canvas.drawText("△", 278f, 85f, white)
        canvas.drawCircle(300f, 101f, 12f, pink); canvas.drawText("○", 300f, 107f, white)
        canvas.drawCircle(256f, 101f, 12f, blue); canvas.drawText("×", 256f, 107f, white)
        canvas.drawCircle(278f, 123f, 12f, red); canvas.drawText("□", 278f, 129f, white)
        // Analog sticks.
        canvas.drawCircle(127f, 143f, 22f, dark); canvas.drawCircle(127f, 143f, 15f, edge)
        canvas.drawCircle(233f, 143f, 22f, dark); canvas.drawCircle(233f, 143f, 15f, edge)
        // Share / options and shoulder labels.
        canvas.drawText("SHARE", 119f, 35f, muted); canvas.drawText("OPTIONS", 241f, 35f, muted)
        canvas.drawText("L1", 89f, 57f, muted); canvas.drawText("R1", 271f, 57f, muted)
        canvas.drawText("L2", 61f, 48f, muted); canvas.drawText("R2", 299f, 48f, muted)
        canvas.restoreToCount(save)
    }
}
