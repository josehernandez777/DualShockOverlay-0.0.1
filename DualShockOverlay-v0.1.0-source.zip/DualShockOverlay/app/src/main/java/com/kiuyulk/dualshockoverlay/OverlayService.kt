package com.kiuyulk.dualshockoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun startAsForeground() {
        val channelId = "dualshock_overlay"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(channelId, "DualShock Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setContentTitle("DualShock Overlay activo")
            .setContentText("Visualizador flotante encendido")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        else @Suppress("DEPRECATION") Notification.Builder(this)
            .setContentTitle("DualShock Overlay activo").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(7, notification)
    }

    private fun showOverlay() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
            background = GradientDrawable().apply {
                setColor(0xDD111116.toInt())
                cornerRadius = 28f
                setStroke(2, 0xFF51466F.toInt())
            }
        }
        val title = TextView(this).apply {
            text = "DUALSHOCK 4  •  OVERLAY"
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val controller = ControllerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(320, 182)
            contentDescription = "Ilustración de mando DualShock 4"
        }
        val hint = TextView(this).apply {
            text = "Vista inicial • arrastra desde el encabezado para mover"
            setTextColor(0xFFAAA4B8.toInt()); textSize = 9f; gravity = Gravity.CENTER
        }
        panel.addView(title); panel.addView(controller); panel.addView(hint)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 110 }
        // The initial overlay is deliberately non-interactive so it cannot steal game touches.
        panel.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> true
                android.view.MotionEvent.ACTION_MOVE -> {
                    params.x += event.rawX.toInt() - (params.x + panel.width / 2)
                    params.y += event.rawY.toInt() - (params.y + panel.height / 2)
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> true
            }
        }
        windowManager.addView(panel, params)
        overlay = panel
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { overlay?.let { windowManager.removeView(it) }; overlay = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
