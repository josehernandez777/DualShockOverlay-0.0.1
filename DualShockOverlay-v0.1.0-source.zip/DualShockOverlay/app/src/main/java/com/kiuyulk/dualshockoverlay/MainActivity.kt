package com.kiuyulk.dualshockoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.hardware.input.InputManager
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity(), InputManager.InputDeviceListener {
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var inputManager: InputManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        inputManager.registerInputDeviceListener(this, null)
        buildUi()
        refreshDevices()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(12, 12, 17))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); setPadding(0, 8, 0, 12)
        }
        root.addView(text("DUALSHOCK OVERLAY", 24f))
        root.addView(text("REAL • DARK • v0.1.0", 12f, Color.LTGRAY))
        status = text("Buscando mando…", 17f, Color.rgb(167, 139, 250))
        root.addView(status)
        details = text("Conecta tu DualShock 4 por Bluetooth y vuelve a comprobar.", 14f, Color.LTGRAY)
        root.addView(details)
        val refresh = Button(this).apply { text = "COMPROBAR MANDO"; setOnClickListener { refreshDevices() } }
        root.addView(refresh)
        val overlay = Button(this).apply {
            text = "ACTIVAR MANDO FLOTANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        root.addView(overlay)
        root.addView(text("PRUEBA DE ENTRADAS", 16f))
        root.addView(text("Esta pantalla puede detectar botones y sticks mientras está abierta. Al cambiar a un juego, Android normalmente entrega esas entradas al juego y no a esta app.", 13f, Color.LTGRAY))
        setContentView(root)
    }

    private fun refreshDevices() {
        val gamepads = inputManager.inputDeviceIds.mapNotNull { inputManager.getInputDevice(it) }
            .filter { it.isGamepad() }
        if (gamepads.isEmpty()) {
            status.text = "● MANDO NO DETECTADO"
            details.text = "Empareja el DualShock 4 en Ajustes > Bluetooth."
        } else {
            status.text = "● ${gamepads.size} CONTROL(ES) DETECTADO(S)"
            details.text = gamepads.joinToString("\n") { "${it.name}  •  ID ${it.id}" }
        }
    }

    private fun InputDevice.isGamepad(): Boolean {
        val sources = sources
        return (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    override fun onInputDeviceAdded(deviceId: Int) = refreshDevices()
    override fun onInputDeviceRemoved(deviceId: Int) = refreshDevices()
    override fun onInputDeviceChanged(deviceId: Int) = refreshDevices()

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN || event.action == KeyEvent.ACTION_UP) {
            details.text = "${KeyEvent.keyCodeToString(event.keyCode)}: ${if (event.action == KeyEvent.ACTION_DOWN) "PRESIONADO" else "LIBERADO"}"
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) {
            val x = event.getAxisValue(MotionEvent.AXIS_X)
            val y = event.getAxisValue(MotionEvent.AXIS_Y)
            val rx = event.getAxisValue(MotionEvent.AXIS_RX)
            val ry = event.getAxisValue(MotionEvent.AXIS_RY)
            details.text = "STICKS  •  L(${"%.2f".format(x)}, ${"%.2f".format(y)})  R(${"%.2f".format(rx)}, ${"%.2f".format(ry)})"
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onDestroy() {
        inputManager.unregisterInputDeviceListener(this)
        super.onDestroy()
    }
}
